import { users, type User, type InsertUser, type Score, type InsertScore } from "@shared/schema";

// modify the interface with any CRUD methods
// you might need

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createScore(score: InsertScore): Promise<Score>;
  getHighScores(): Promise<Score[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private scores: Map<number, Score>;
  currentId: number;
  currentScoreId: number;

  constructor() {
    this.users = new Map();
    this.scores = new Map();
    this.currentId = 1;
    this.currentScoreId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  async createScore(insertScore: InsertScore): Promise<Score> {
    const id = this.currentScoreId++;
    // Make sure player has a default value
    const scoreData = {
      ...insertScore,
      player: insertScore.player || "Player",
      id
    };
    this.scores.set(id, scoreData);
    return scoreData;
  }
  
  async getHighScores(): Promise<Score[]> {
    return Array.from(this.scores.values())
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);
  }
}

export const storage = new MemStorage();
