import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const scores = pgTable("scores", {
  id: serial("id").primaryKey(),
  player: text("player").notNull().default("Player"),
  score: integer("score").notNull(),
  round: integer("round").notNull(),
  difficulty: text("difficulty").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Create the insert schema for scores
export const scoreSchema = createInsertSchema(scores).pick({
  player: true,
  score: true,
  round: true,
  difficulty: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type Score = typeof scores.$inferSelect;
export type InsertScore = {
  player: string;
  score: number;
  round: number;
  difficulty: string;
};
