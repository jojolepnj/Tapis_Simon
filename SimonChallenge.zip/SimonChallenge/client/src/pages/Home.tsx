import { useState, useContext } from "react";
import { useLocation } from "wouter";
import { LanguageContext } from "@/contexts/LanguageContext";
import LanguageSelector from "@/components/LanguageSelector";
import Footer from "@/components/Footer";

const Home = () => {
  const [difficulty, setDifficulty] = useState("");
  const [, setLocation] = useLocation();
  const { t } = useContext(LanguageContext);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (difficulty) {
      setLocation(`/game/${difficulty}`);
    }
  };

  return (
    <div className="bg-dark text-light min-h-screen overflow-x-hidden">
      <div className="container mx-auto px-4 py-6 min-h-screen flex flex-col">
        <header className="game-header">
          <h1 className="game-title">{t.title}</h1>
        </header>

        <main className="game-panel">
          <div className="control-panel panel">
            <h2>{t.choose_level}</h2>
            <form id="difficulty-form" className="difficulty-form" onSubmit={handleSubmit}>
              <select 
                className="form-select" 
                value={difficulty} 
                onChange={(e) => setDifficulty(e.target.value)}
                required
              >
                <option value="" disabled>{t.select_difficulty}</option>
                <option value="easy">{t.easy}</option>
                <option value="medium">{t.medium}</option>
                <option value="hard">{t.hard}</option>
              </select>
              <button type="submit" className="btn-primary">
                {t.start_game}
              </button>
            </form>
          </div>

          <div className="highscores-panel panel">
            <h2>{t.high_scores}</h2>
            <div style={{ overflowX: "auto" }}>
              <table className="score-table">
                <thead>
                  <tr>
                    <th>{t.position}</th>
                    <th>{t.player}</th>
                    <th>{t.score}</th>
                    <th>{t.difficulty}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>🥇</td>
                    <td>Player 1</td>
                    <td>15</td>
                    <td><span className="difficulty-badge hard-badge">{t.hard_badge}</span></td>
                  </tr>
                  <tr>
                    <td>🥈</td>
                    <td>Player 2</td>
                    <td>12</td>
                    <td><span className="difficulty-badge medium-badge">{t.medium_badge}</span></td>
                  </tr>
                  <tr>
                    <td>🥉</td>
                    <td>Player 3</td>
                    <td>10</td>
                    <td><span className="difficulty-badge easy-badge">{t.easy_badge}</span></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </main>

        <Footer />

        <LanguageSelector />
      </div>
    </div>
  );
};

export default Home;
