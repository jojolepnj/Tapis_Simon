import { useState, useEffect, useContext, useRef } from 'react';
import { useParams, useLocation } from 'wouter';
import { LanguageContext } from '@/contexts/LanguageContext';
import SimonBoard from '@/components/SimonBoard';
import GameStatus from '@/components/GameStatus';
import GameControls from '@/components/GameControls';
import GameOverModal from '@/components/GameOverModal';
import Footer from '@/components/Footer';
import LanguageSelector from '@/components/LanguageSelector';
import { DIFFICULTY_SETTINGS, Color } from '@/lib/gameUtils';

// Définition des notes de musique pour chaque couleur
const NOTES = {
  green: 329.63,  // E4
  red: 392.00,    // G4
  yellow: 440.00, // A4
  blue: 493.88     // B4
};

const Game = () => {
  const { difficulty = 'easy' } = useParams<{ difficulty: 'easy' | 'medium' | 'hard' }>();
  const [, setLocation] = useLocation();
  const { t } = useContext(LanguageContext);
  
  // Game state
  const [pattern, setPattern] = useState<Color[]>([]);
  const [playerPattern, setPlayerPattern] = useState<Color[]>([]);
  const [round, setRound] = useState(1);
  const [score, setScore] = useState(0);
  const [gameActive, setGameActive] = useState(false);
  const [playerTurn, setPlayerTurn] = useState(false);
  const [gameStatus, setGameStatus] = useState('get_ready');
  const [activeButton, setActiveButton] = useState<Color | null>(null);
  const [showModal, setShowModal] = useState(false);
  
  // Références pour éviter les problèmes de course condition
  const isPlayingRef = useRef(false);
  const gameActiveRef = useRef(false);
  
  // Audio Context et Oscillateurs
  const audioRef = useRef<{
    context: AudioContext | null;
    oscillators: Record<Color, OscillatorNode | null>;
    gains: Record<Color, GainNode | null>;
  }>({
    context: null,
    oscillators: { green: null, red: null, yellow: null, blue: null },
    gains: { green: null, red: null, yellow: null, blue: null }
  });
  
  // Initialiser l'audio
  useEffect(() => {
    // Fonction pour initialiser l'audio
    const initAudio = () => {
      try {
        // Créer le contexte audio
        const AudioContext = window.AudioContext || (window as any).webkitAudioContext;
        if (!AudioContext) {
          console.error("Web Audio API non supportée");
          return;
        }
        
        // Initialiser le contexte audio
        const context = new AudioContext();
        audioRef.current.context = context;
        
        // Créer les oscillateurs et les gains pour chaque couleur
        Object.entries(NOTES).forEach(([color, frequency]) => {
          const oscillator = context.createOscillator();
          const gain = context.createGain();
          
          oscillator.type = 'sine';
          oscillator.frequency.value = frequency;
          gain.gain.value = 0;
          
          oscillator.connect(gain);
          gain.connect(context.destination);
          
          oscillator.start();
          
          audioRef.current.oscillators[color as Color] = oscillator;
          audioRef.current.gains[color as Color] = gain;
        });
      } catch (error) {
        console.error("Erreur lors de l'initialisation de l'audio:", error);
      }
    };
    
    // Initialiser l'audio au premier clic
    const handleFirstInteraction = () => {
      initAudio();
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('keydown', handleFirstInteraction);
    };
    
    window.addEventListener('click', handleFirstInteraction);
    window.addEventListener('keydown', handleFirstInteraction);
    
    // Nettoyage
    return () => {
      window.removeEventListener('click', handleFirstInteraction);
      window.removeEventListener('keydown', handleFirstInteraction);
      
      // Arrêter tous les oscillateurs
      if (audioRef.current.context) {
        Object.values(audioRef.current.oscillators).forEach(osc => {
          if (osc) {
            osc.stop();
            osc.disconnect();
          }
        });
        
        // Fermer le contexte audio
        audioRef.current.context.close().catch(err => {
          console.error("Erreur lors de la fermeture du contexte audio:", err);
        });
      }
    };
  }, []);
  
  // Jouer un son
  const playSound = (color: Color) => {
    // Vérifier si l'audio est initialisé
    if (!audioRef.current.context || !audioRef.current.gains[color]) {
      console.log("Audio non initialisé");
      return;
    }
    
    try {
      const context = audioRef.current.context;
      const gain = audioRef.current.gains[color];
      
      if (gain) {
        // Annuler les valeurs précédentes
        const now = context.currentTime;
        gain.gain.cancelScheduledValues(now);
        
        // Ramper le gain pour créer l'attaque et la chute du son
        gain.gain.setValueAtTime(0, now);
        gain.gain.linearRampToValueAtTime(0.7, now + 0.1);
        gain.gain.linearRampToValueAtTime(0, now + 0.5);
      }
    } catch (error) {
      console.error("Erreur lors de la lecture du son:", error);
    }
  };
  
  // Activer un bouton (visuel + son)
  const activateButton = (color: Color) => {
    // Désactiver d'abord le bouton actif pour garantir l'animation
    setActiveButton(null);
    
    // Petit délai pour s'assurer que le state est mis à jour
    setTimeout(() => {
      // Activer le bouton et jouer le son
      setActiveButton(color);
      playSound(color);
      
      // Désactiver après la durée du flash
      setTimeout(() => {
        setActiveButton(null);
      }, DIFFICULTY_SETTINGS[difficulty].flashSpeed);
    }, 10);
  };
  
  // Ajouter une couleur aléatoire au motif
  const addToPattern = () => {
    const colors: Color[] = ['green', 'red', 'yellow', 'blue'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];
    setPattern(prev => [...prev, randomColor]);
    setRound(prev => prev + 1);
  };
  
  // Jouer la séquence de motif actuelle
  const playPattern = async () => {
    // Éviter de jouer plusieurs séquences simultanément
    if (isPlayingRef.current) return;
    isPlayingRef.current = true;
    
    // Mettre à jour l'état du jeu
    setGameStatus('watch_pattern');
    setPlayerTurn(false);
    
    // Délai avant de commencer la séquence
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    try {
      // Jouer chaque bouton dans la séquence
      for (let i = 0; i < pattern.length; i++) {
        // Arrêter si le jeu a été réinitialisé
        if (!gameActiveRef.current) break;
        
        const color = pattern[i];
        activateButton(color);
        
        // Attendre la fin du flash + pause
        await new Promise(resolve => setTimeout(resolve, 
          DIFFICULTY_SETTINGS[difficulty].flashSpeed + 
          DIFFICULTY_SETTINGS[difficulty].pauseBetween
        ));
      }
      
      // Tour du joueur
      if (gameActiveRef.current) {
        setPlayerTurn(true);
        setPlayerPattern([]);
        setGameStatus('your_turn');
      }
    } catch (error) {
      console.error("Erreur lors de la lecture du motif:", error);
    } finally {
      isPlayingRef.current = false;
    }
  };
  
  // Gérer le clic sur un bouton
  const handleButtonClick = (color: Color) => {
    // Vérifier si c'est le tour du joueur et si le jeu est actif
    if (!playerTurn || !gameActive) return;
    
    // Activer le bouton et jouer le son
    activateButton(color);
    
    // Ajouter la couleur au motif du joueur
    const newPlayerPattern = [...playerPattern, color];
    setPlayerPattern(newPlayerPattern);
    
    // Vérifier si le mouvement est correct
    const currentIndex = newPlayerPattern.length - 1;
    if (newPlayerPattern[currentIndex] !== pattern[currentIndex]) {
      // Mauvais mouvement - fin de jeu
      endGame();
      return;
    }
    
    // Vérifier si le motif est complet
    if (newPlayerPattern.length === pattern.length) {
      // Motif correct - ajouter au score
      setScore(prev => prev + (10 * round));
      setPlayerTurn(false);
      setGameStatus('correct');
      
      // Délai avant le prochain round
      setTimeout(() => {
        if (!gameActiveRef.current) return;
        
        // Ajouter une nouvelle couleur au motif
        addToPattern();
      }, 1500);
    }
  };
  
  // Démarrer un nouveau jeu
  const startGame = () => {
    if (gameActive) return;
    
    // Initialiser/réinitialiser l'état du jeu
    setPattern([]);
    setPlayerPattern([]);
    setRound(0);
    setScore(0);
    setGameActive(true);
    gameActiveRef.current = true;
    setGameStatus('get_ready');
    setShowModal(false);
    
    // Ajouter le premier élément du motif et commencer
    setTimeout(() => {
      addToPattern();
    }, 1000);
  };
  
  // Réinitialiser le jeu actuel
  const resetGame = () => {
    setGameActive(false);
    gameActiveRef.current = false;
    setPlayerTurn(false);
    setPattern([]);
    setPlayerPattern([]);
    setRound(0);
    setScore(0);
    setGameStatus('game_reset');
  };
  
  // Terminer le jeu
  const endGame = () => {
    setGameActive(false);
    gameActiveRef.current = false;
    setPlayerTurn(false);
    setShowModal(true);
    
    // Jouer un son d'erreur
    try {
      if (audioRef.current.context) {
        const context = audioRef.current.context;
        const errorOscillator = context.createOscillator();
        const errorGain = context.createGain();
        
        errorOscillator.type = 'sawtooth';
        errorOscillator.frequency.value = 150;
        errorGain.gain.value = 0;
        
        errorOscillator.connect(errorGain);
        errorGain.connect(context.destination);
        
        errorOscillator.start();
        
        // Créer le son d'erreur
        const now = context.currentTime;
        errorGain.gain.setValueAtTime(0, now);
        errorGain.gain.linearRampToValueAtTime(0.5, now + 0.1);
        errorGain.gain.linearRampToValueAtTime(0, now + 0.5);
        
        // Arrêter l'oscillateur après le son
        setTimeout(() => {
          errorOscillator.stop();
          errorOscillator.disconnect();
          errorGain.disconnect();
        }, 600);
      }
    } catch (error) {
      console.error("Erreur lors de la lecture du son d'erreur:", error);
    }
  };
  
  // Redémarrer le jeu
  const restartGame = () => {
    setShowModal(false);
    setTimeout(startGame, 500);
  };
  
  // Retourner au menu
  const returnToMenu = () => {
    setLocation('/');
  };
  
  // Effet pour surveiller les mises à jour du motif
  useEffect(() => {
    if (pattern.length > 0 && gameActive) {
      playPattern();
    }
  }, [pattern.length, gameActive]);
  
  // Effet pour mettre à jour gameActiveRef
  useEffect(() => {
    gameActiveRef.current = gameActive;
  }, [gameActive]);
  
  const statusMapping: Record<string, keyof typeof t> = {
    get_ready: 'gameReady',
    watch_pattern: 'watchPattern',
    your_turn: 'yourTurn',
    correct: 'correct',
    game_reset: 'gameReset'
  };
  
  const statusText = t[statusMapping[gameStatus] || 'gameReady'];
  
  const statusClassMap: Record<string, string> = {
    get_ready: 'text-simon-green',
    watch_pattern: 'text-simon-blue',
    your_turn: 'text-simon-yellow',
    correct: 'text-simon-green',
    game_reset: 'text-gray-400'
  };
  
  const statusClass = `text-xl font-bold ${statusClassMap[gameStatus] || 'text-simon-green'}`;
  
  return (
    <div className="bg-dark text-light min-h-screen overflow-x-hidden">
      <div className="container mx-auto px-4 py-6 min-h-screen flex flex-col">
        <header className="text-center py-4 md:py-8">
          <h1 className="game-title">{t.title}</h1>
        </header>
        
        <main className="flex-grow flex flex-col items-center justify-center py-4">
          <GameStatus 
            statusText={statusText} 
            statusClass={statusClass}
            round={round}
            score={score}
            roundLabel={t.round}
            scoreLabel={t.score}
          />
          
          <SimonBoard 
            activeButton={activeButton} 
            onButtonClick={handleButtonClick}
            isPlayerTurn={playerTurn}
          />
          
          <GameControls 
            onStart={startGame}
            onReset={resetGame}
            startText={t.start}
            resetText={t.reset}
          />
          
          <div className="mt-4 text-center">
            <span className="text-sm opacity-70">{t.difficulty}</span>
            <span className={`ml-2 px-3 py-1 ${difficulty === 'easy' ? 'bg-[#00cc66]' : difficulty === 'medium' ? 'bg-[#ffcc00]' : 'bg-[#ff3333]'} text-white text-sm rounded-full font-bold uppercase ${difficulty === 'medium' ? 'text-black' : ''}`}>
              {difficulty === 'easy' ? t.easy_badge : difficulty === 'medium' ? t.medium_badge : t.hard_badge}
            </span>
          </div>
        </main>
        
        <Footer />
        
        <LanguageSelector />
        
        <GameOverModal
          show={showModal}
          score={score}
          round={round}
          difficulty={difficulty}
          onRestart={restartGame}
          onReturn={returnToMenu}
          t={t}
        />
      </div>
    </div>
  );
};

export default Game;
