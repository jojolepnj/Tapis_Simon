import { createContext, useState, useEffect, ReactNode } from "react";
import { translations } from "@/lib/translations";

type LanguageType = "en" | "fr" | "de";

interface LanguageContextType {
  language: LanguageType;
  setLanguage: (lang: LanguageType) => void;
  t: typeof translations["en"];
}

export const LanguageContext = createContext<LanguageContextType>({
  language: "en",
  setLanguage: () => {},
  t: translations.en
});

interface LanguageProviderProps {
  children: ReactNode;
}

export const LanguageProvider = ({ children }: LanguageProviderProps) => {
  const [language, setLanguage] = useState<LanguageType>("en");
  
  useEffect(() => {
    // Try to get language preference from localStorage
    const savedLanguage = localStorage.getItem("simon-language") as LanguageType | null;
    if (savedLanguage && (savedLanguage === "en" || savedLanguage === "fr" || savedLanguage === "de")) {
      setLanguage(savedLanguage);
    }
  }, []);
  
  const handleLanguageChange = (lang: LanguageType) => {
    setLanguage(lang);
    localStorage.setItem("simon-language", lang);
  };
  
  return (
    <LanguageContext.Provider 
      value={{ 
        language, 
        setLanguage: handleLanguageChange, 
        t: translations[language] 
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};
