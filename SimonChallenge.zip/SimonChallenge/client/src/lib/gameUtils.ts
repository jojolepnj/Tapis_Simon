export type Color = 'green' | 'red' | 'yellow' | 'blue';

export interface DifficultySettings {
  flashSpeed: number;  // How long a button stays lit (ms)
  pauseBetween: number; // Pause between button flashes (ms)
}

export const DIFFICULTY_SETTINGS: Record<string, DifficultySettings> = {
  easy: { flashSpeed: 800, pauseBetween: 400 },
  medium: { flashSpeed: 500, pauseBetween: 300 },
  hard: { flashSpeed: 300, pauseBetween: 200 }
};
