import { translations } from "@/lib/translations";

interface GameOverModalProps {
  show: boolean;
  score: number;
  round: number;
  difficulty: string;
  onRestart: () => void;
  onReturn: () => void;
  t: typeof translations["en"];
}

const GameOverModal = ({ show, score, round, difficulty, onRestart, onReturn, t }: GameOverModalProps) => {
  if (!show) return null;
  
  const difficultyColorClass = 
    difficulty === "easy" ? "text-simon-green" :
    difficulty === "medium" ? "text-simon-yellow" :
    "text-simon-red";
  
  const difficultyText = 
    difficulty === "easy" ? t.easy_badge :
    difficulty === "medium" ? t.medium_badge :
    t.hard_badge;
  
  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 backdrop-effect">
      <div className="bg-dark border-2 border-gray-700 rounded-xl p-6 w-full max-w-md text-center shadow-2xl mx-4">
        <h2 className="text-3xl font-bold mb-2">{t.gameOver}</h2>
        <p className="text-xl mb-4">
          {t.finalScore} <span className="font-bold text-simon-yellow">{score}</span>
        </p>
        <p className="mb-6">
          {t.reachedRound} <span className="font-bold">Round {round}</span> {t.on} <span className={`font-bold ${difficultyColorClass}`}>{difficultyText}</span>
        </p>
        
        <div className="flex flex-wrap gap-3 justify-center">
          <button
            onClick={onRestart}
            className="px-5 py-2 bg-simon-blue rounded-lg font-bold transition-all hover:bg-opacity-80"
          >
            {t.playAgain}
          </button>
          <button
            onClick={onReturn}
            className="px-5 py-2 bg-gray-600 rounded-lg font-bold transition-all hover:bg-opacity-80"
          >
            {t.mainMenu}
          </button>
        </div>
      </div>
    </div>
  );
};

export default GameOverModal;
