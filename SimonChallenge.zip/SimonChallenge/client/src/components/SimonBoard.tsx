import { useState, useEffect } from "react";
import { Color } from "@/lib/gameUtils";

interface SimonBoardProps {
  activeButton: Color | null;
  onButtonClick: (color: Color) => void;
  isPlayerTurn: boolean;
}

const SimonBoard = ({ activeButton, onButtonClick, isPlayerTurn }: SimonBoardProps) => {
  // Gestionnaire de clic manuel pour chaque bouton
  const handleButtonClick = (color: Color) => {
    if (isPlayerTurn) {
      console.log(`Button clicked: ${color}`);
      onButtonClick(color);
    }
  };

  return (
    <div className="relative w-full max-w-md aspect-square rounded-full bg-[#1a1a2e]/90 p-4 shadow-[0_0_40px_rgba(0,0,0,0.5)] mb-8">
      <div className="absolute inset-0 rounded-full border-8 border-gray-800"></div>
      
      {/* Centre du jeu */}
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[100px] h-[100px] rounded-full bg-gray-900 z-10 flex items-center justify-center shadow-[inset_0_0_20px_rgba(0,0,0,0.5)]">
        <div className="text-3xl font-bold uppercase tracking-[4px] bg-clip-text bg-gradient-to-r from-[#00cc66] via-[#3399ff] to-[#ff3333] text-transparent">Simon</div>
      </div>
      
      {/* Conteneur des boutons */}
      <div className="w-full h-full grid grid-cols-2 grid-rows-2 gap-4 p-3">
        {/* Bouton Vert (Haut Gauche) */}
        <a 
          href="#" 
          id="green-button" 
          className={`simon-button bg-[#00cc66]/70 hover:bg-[#00cc66]/90 cursor-pointer rounded-tl-[100%] shadow-md transition-all ${activeButton === 'green' ? 'simon-green-active' : ''}`}
          onClick={(e) => { e.preventDefault(); handleButtonClick('green'); }}
          style={{ borderTopLeftRadius: '100%', borderBottomRightRadius: '10%' }}
          aria-label="Bouton vert"
        ></a>
        
        {/* Bouton Rouge (Haut Droite) */}
        <a 
          href="#" 
          id="red-button" 
          className={`simon-button bg-[#ff3333]/70 hover:bg-[#ff3333]/90 cursor-pointer rounded-tr-[100%] shadow-md transition-all ${activeButton === 'red' ? 'simon-red-active' : ''}`}
          onClick={(e) => { e.preventDefault(); handleButtonClick('red'); }}
          style={{ borderTopRightRadius: '100%', borderBottomLeftRadius: '10%' }}
          aria-label="Bouton rouge"
        ></a>
        
        {/* Bouton Jaune (Bas Gauche) */}
        <a 
          href="#" 
          id="yellow-button" 
          className={`simon-button bg-[#ffcc00]/70 hover:bg-[#ffcc00]/90 cursor-pointer rounded-bl-[100%] shadow-md transition-all ${activeButton === 'yellow' ? 'simon-yellow-active' : ''}`}
          onClick={(e) => { e.preventDefault(); handleButtonClick('yellow'); }}
          style={{ borderBottomLeftRadius: '100%', borderTopRightRadius: '10%' }}
          aria-label="Bouton jaune"
        ></a>
        
        {/* Bouton Bleu (Bas Droite) */}
        <a 
          href="#" 
          id="blue-button" 
          className={`simon-button bg-[#3399ff]/70 hover:bg-[#3399ff]/90 cursor-pointer rounded-br-[100%] shadow-md transition-all ${activeButton === 'blue' ? 'simon-blue-active' : ''}`}
          onClick={(e) => { e.preventDefault(); handleButtonClick('blue'); }}
          style={{ borderBottomRightRadius: '100%', borderTopLeftRadius: '10%' }}
          aria-label="Bouton bleu"
        ></a>
      </div>
    </div>
  );
};

export default SimonBoard;
