import { useContext } from "react";
import { LanguageContext } from "@/contexts/LanguageContext";

const LanguageSelector = () => {
  const { language, setLanguage } = useContext(LanguageContext);
  
  const changeLanguage = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setLanguage(e.target.value as "en" | "fr" | "de");
  };
  
  return (
    <div className="language-selector">
      <select 
        id="languageSelect" 
        value={language} 
        onChange={changeLanguage}
      >
        <option value="fr">🇫🇷 Français</option>
        <option value="en">🇬🇧 English</option>
        <option value="de">🇩🇪 Deutsch</option>
      </select>
    </div>
  );
};

export default LanguageSelector;
