import { useContext } from "react";
import { LanguageContext } from "@/contexts/LanguageContext";

const Footer = () => {
  const { t } = useContext(LanguageContext);
  
  return (
    <footer className="mt-auto py-4">
      <div className="flex justify-between items-center">
        <div className="text-sm opacity-70">
          {t.footer}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
