interface GameStatusProps {
  statusText: string;
  statusClass: string;
  round: number;
  score: number;
  roundLabel: string;
  scoreLabel: string;
}

const GameStatus = ({ 
  statusText, 
  statusClass, 
  round, 
  score,
  roundLabel,
  scoreLabel
}: GameStatusProps) => {
  return (
    <div className="w-full max-w-md bg-[#1a1a2e]/80 backdrop-effect rounded-xl border-2 border-[#3399ff] shadow-[0_0_20px_rgba(51,153,255,0.3)] mb-8 p-4 animate-glow">
      <div className="flex justify-between items-center">
        <div className={statusClass}>
          {statusText}
        </div>
        <div className="flex gap-6">
          <div className="text-center">
            <div className="text-sm opacity-70">{roundLabel}</div>
            <div className="text-xl font-bold">{round}</div>
          </div>
          <div className="text-center">
            <div className="text-sm opacity-70">{scoreLabel}</div>
            <div className="text-xl font-bold">{score}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GameStatus;
