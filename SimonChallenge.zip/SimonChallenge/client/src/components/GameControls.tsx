interface GameControlsProps {
  onStart: () => void;
  onReset: () => void;
  startText: string;
  resetText: string;
}

const GameControls = ({ onStart, onReset, startText, resetText }: GameControlsProps) => {
  return (
    <div className="w-full max-w-md flex flex-wrap gap-4 justify-center">
      <button
        onClick={onStart}
        className="px-6 py-3 bg-gradient-to-r from-[#00cc66] to-[#3399ff] rounded-lg text-white font-bold uppercase tracking-wider shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all"
      >
        {startText}
      </button>
      
      <button
        onClick={onReset}
        className="px-6 py-3 bg-gradient-to-r from-[#ffcc00] to-[#ff3333] rounded-lg text-white font-bold uppercase tracking-wider shadow-lg hover:shadow-xl transform hover:-translate-y-1 transition-all"
      >
        {resetText}
      </button>
    </div>
  );
};

export default GameControls;
